#ifndef TYPECHECK_H_
#define TYPECHECK_H_

void typecheck(AST_node_ *root);


#endif /*TYPECHECK_H_*/
