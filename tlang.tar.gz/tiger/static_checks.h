#if ! defined _STATIC_CHECKS_H
#define _STATIC_CHECKS_H 1

#include "AST.h"

void perform_static_checks(AST_node_ *root);

#endif
