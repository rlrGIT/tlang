#include "AST.h"
#include "static_checks.h"


void perform_static_checks(AST_node_ *root)
{
	// trigger the computation of AST attributes to detect bad breaks, etc.
}
