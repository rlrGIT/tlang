#include "AST.h"

void layout_frames(AST_node_ *root)
{
	// do what it takes to set up frames
}

